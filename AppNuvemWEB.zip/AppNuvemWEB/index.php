<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Gestão Industrial</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f4f4; }
        h1 { color: #333; }
        .btn-abrir { padding: 10px 15px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
        dialog { border: none; border-radius: 8px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        dialog::backdrop { background: rgba(0, 0, 0, 0.5); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background: #007bff; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
    </style>
</head>
<body>
    <h1>App Nuvem Web</h1>
    
    <button id="abrirModalInserir" class="btn-abrir">Abrir Modal de Inserção</button>

    
    <dialog id="meuModalEditar">
        <form method="dialog">
            <h2>EDITAR DADOS</h2>
            <input type="hidden" id="edit-id" name="id">
            
            <label>Nome:</label><br>
            <input type="text" id="edit-nome" name="nome"><br><br>
            
            <label>Celular:</label><br>
            <input type="text" id="edit-celular" name="celular"><br><br>

            <button type="button" id="fecharModalEditar">Cancelar</button>
            <button type="submit" style="background: #28a745; color: white;">Salvar Alterações</button>
        </form>
    </dialog>

    <dialog id="meuModalInserir">
        <h2>INSESIR NOVOS DADOS</h2>
        <p>Corpo</p>
        <button id="fecharModal">Fechar</button>
    </dialog>


    <h2>Dados do banco</h2>
    
    <?php
    include 'conexao.php'; // Certifique-se que este arquivo usa PDO

    try {
        $sql = "SELECT * FROM clientes";
        $stmt = $pdo->query($sql);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        if (count($rows) > 0) {
            // Inicia a tabela e cabeçalhos
            echo "<table>";
            echo "<tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Celular</th>
                    <th>Data Nasc.</th>
                    <th>Gênero</th>
                    <th>Editar</th>
                    <th>Ecluir</th>
                  </tr>";
    
            // Preenche as linhas
            foreach ($rows as $row) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
                echo "<td>" . htmlspecialchars($row['celular']) . "</td>";
                echo "<td>" . htmlspecialchars($row['datanasc']) . "</td>";
                echo "<td>" . htmlspecialchars($row['genero']) . "</td>";
                
                echo '<td><button class="btn-editar" onclick="abrirModalEdicao(' . $row['id'] . ', \'' . htmlspecialchars($row['nome'], ENT_QUOTES) . '\', \'' . htmlspecialchars($row['celular'], ENT_QUOTES) . '\', \'' . $row['datanasc'] . '\', \'' . $row['genero'] . '\')">Editar</button></td>';
    
                echo "<td><button style='background: #dc3545; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer;' onclick='excluirCliente(" . $row['id'] . ")'>Excluir</button></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>Nenhum cliente encontrado.</p>";
        }
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
    ?>

    <script>
        
        const modal = document.getElementById('meuModalInserir');
        const abrirBtn = document.getElementById('abrirModalInserir');
        const fecharBtn = document.getElementById('fecharModal');

        // Abrir modal
        abrirBtn.addEventListener('click', () => {
            modal.showModal(); 
        });

        // Fechar modal
        fecharBtn.addEventListener('click', () => {
            modal.close();
        });
    </script>

    <script>
        // Modal Inserir
        const modalInserir = document.getElementById('meuModalInserir');
        const abrirBtnInserir = document.getElementById('abrirModalInserir');
        const fecharBtnInserir = document.getElementById('fecharModal');

        abrirBtnInserir.addEventListener('click', () => modalInserir.showModal());
        fecharBtnInserir.addEventListener('click', () => modalInserir.close());

        // --- MODAL EDITAR (Funcionalidade principal da pergunta) ---
        const modalEditar = document.getElementById('meuModalEditar');
        const fecharBtnEditar = document.getElementById('fecharModalEditar');
        const spanId = document.getElementById('idEdicao');

        // Seleciona todos os botões com a classe .btn-editar-tabela
        document.querySelectorAll('.btn-editar-tabela').forEach(button => {
            button.addEventListener('click', () => {
                const id = button.getAttribute('data-id');
                spanId.innerText = id; // Opcional: mostra o ID no modal
                modalEditar.showModal();
                // Aqui você geralmente faria um fetch/ajax para buscar os dados do ID
            });
        });

        fecharBtnEditar.addEventListener('click', () => modalEditar.close());
    </script>
</body>
</html>

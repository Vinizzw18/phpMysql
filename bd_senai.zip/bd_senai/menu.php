<?php
    if(empty($_SESSION["user"])){
        echo "";
    }
    else {
        $usuario = $_SESSION["user"];
        echo "<a href='relatorio.php' style='color: white; text-decoration: none; font-weight: bold;'>#</a>";
        echo "<b><font color='white'> | </font></b>";
        echo "<a href='relatorio2.php' style='color: white; text-decoration: none; font-weight: bold;'>#</a>";
        echo "<b><font color='white'> | </font></b>";
        echo "<a href='#' style='color: white; text-decoration: none; font-weight: bold;'>#</a>";
        echo "<b><font color='white'> | </font></b>";
        echo "<a href='#' style='color: white; text-decoration: none; font-weight: bold;'>#</a>";
    }
?>
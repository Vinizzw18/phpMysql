<?php
session_start();
include 'conecta.php'; // Certifica-te de que este ficheiro define a variável $pdo

// 1. Captura os dados do formulário
$login = $_POST['usuario'] ?? '';
$senha = $_POST['senha'] ?? '';

try {
    // 2. Prepara a consulta (evita SQL Injection)
    // Usamos :usuario e :senha como placeholders
    $sql = "SELECT * FROM tb_usuarios WHERE login = :usuario AND senha = :senha";
    $stmt = $pdo->prepare($sql);

    // 3. Vincula os valores e executa
    $stmt->execute([
        ':usuario' => $login,
        ':senha'   => $senha // Se usares criptografia, aqui entraria a variável criptografada
    ]);

    // 4. Verifica se encontrou algum registo
    $usuario = $stmt->fetch();

    if ($usuario) {
        // Login com sucesso
        $_SESSION["user"] = $usuario["login"];
        $_SESSION["user_nome"]  = $usuario["nome_usuario"];
        echo "<script>window.location.replace('suporte.php');</script>";
    } else {
        // Falha no login
        echo "<script>alert('Login ou senha incorretos! Tente novamente.');</script>";
        echo "<script>window.location.replace('index.php');</script>";
    }

} catch (PDOException $e) {
    // Erro na execução da query
    die("Erro ao selecionar no banco de dados: " . $e->getMessage());
}

// Nota: No PDO, não é estritamente necessário fechar a conexão, 
// ela fecha sozinha ao fim do script, mas podes fazer $pdo = null; se desejares.
?>


<?php
  session_start();
  //if(!isset($_SESSION["user"]))
  //{
    //echo "<script language='javascript' type='text/javascript'> 
    //window.location.href='http://senaisgr.com.br/suporte/index.php';
    //</script>";
    //exit;
  //}
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="content-language" content="pt-br">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="imagens/senai_png.png" type="image/png">
    <title>BD SENAI</title>
    <link href="scripts/bootstrap5/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
          background-color: #08546c;
         }
    .header {
      float: right;
    }
    .letra {
      font-size: small;
    }
</style>
  </head>
  <body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="scripts/bootstrap5/js/bootstrap.min.js"></script>
    <div class="container-fluid">
      <img src="imagens/senainegativo.png" width="20%" height="20%">
      <?php
      echo "<div class='header'>";
      if (empty($_SESSION["user"])){
        echo "<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='white' class='bi bi-person-square' viewBox='0 0 16 16'>
        <path d='M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z'/>
        <path d='M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12z'/>
      </svg> <a href='log.php' style='color: white; text-decoration: none; font-weight: bold;'>Login | </a>";
        echo "<a href='sair.php' style='color: white; text-decoration: none; font-weight: bold;'> Sair</a>";
      }
      else {
        $usuario = $_SESSION["user"];
        echo "<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='white' class='bi bi-person-square' viewBox='0 0 16 16'>
        <path d='M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z'/>
        <path d='M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12z'/>
      </svg><b><font color='white'> ".$usuario." | </font></b>";
        echo "<a href='sair.php' style='color: white; text-decoration: none; font-weight: bold;'> Sair</a>";
      }
      echo "</div>";
      ?>
      <hr>
      <nav>
        <?php
          include 'menu.php';
        ?>
      </nav>
      <br>
      <center>
      <h1><p class="text-white">RELATÓRIO 2</p></h1>
      </center>
      <br>
      <div class="row row-cols-2 row-cols-md-1 mb-3 text-center">
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
        <div class="card-header py-3">
            <h4 class="my-0 fw-normal"><b><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-diagram-3" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6 3.5A1.5 1.5 0 0 1 7.5 2h1A1.5 1.5 0 0 1 10 3.5v1A1.5 1.5 0 0 1 8.5 6v1H14a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0v-1A.5.5 0 0 1 2 7h5.5V6A1.5 1.5 0 0 1 6 4.5v-1zM8.5 5a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1zM0 11.5A1.5 1.5 0 0 1 1.5 10h1A1.5 1.5 0 0 1 4 11.5v1A1.5 1.5 0 0 1 2.5 14h-1A1.5 1.5 0 0 1 0 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5A1.5 1.5 0 0 1 7.5 10h1a1.5 1.5 0 0 1 1.5 1.5v1A1.5 1.5 0 0 1 8.5 14h-1A1.5 1.5 0 0 1 6 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5a1.5 1.5 0 0 1 1.5-1.5h1a1.5 1.5 0 0 1 1.5 1.5v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"/>
            </svg>&nbsp;&nbsp;PRODUÇÃO / MÁQUINA / PERÍODO</b></h4>
          </div>
          <div class="card-body" style="text-align: left;">
            <?php
              include 'conecta.php';
              try {
                    $consulta = $pdo->query("SELECT m.tag_maquina AS 'Equipamento', m.tipo_maquina AS 'Tipo', SUM(p.qtd_produzida) AS 'Volume_Total', COUNT(p.id_registro) AS 'Vezes_Operada' FROM tb_maquinas m INNER JOIN tb_producao p ON m.id_maquina = p.id_maquina GROUP BY m.tag_maquina, m.tipo_maquina ORDER BY Volume_Total DESC");
                    $relatorio = $consulta->fetchAll();
                  } catch (PDOException $e) {
                    die("Erro ao carregar dados: " . $e->getMessage());
                  }
            ?>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th class="letra" scope="col">EQUIPAMENTO </th>
                  <th class="letra" scope="col">TIPO</th>
                  <th class="letra" scope="col">VOLUME TOTAL</th>
                  <th class="letra" scope="col">VEZES OPERADA</th>             
                </tr>
              </thead>
              <tbody>
                <?php if ($relatorio): ?>
                <?php foreach ($relatorio as $linha): ?>
                <tr>
                  <td><?php echo $linha['Equipamento']; ?></td>
                  <td><?php echo $linha['Tipo']; ?></td>
                  <td><?php echo $linha['Volume_Total']; ?></td>
                  <td><?php echo $linha['Vezes_Operada']; ?></td>
                  
                </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr>
                  <td colspan="4" class="text-center">Nenhum dado de produção encontrado.</td>
                </tr>
                <?php endif; ?>
              </tbody>
              </table>
            </svg><b>Voltar</b></button>
          </div>
        </div>
      </div>
    </div>
    </div>
  </body>
</html>